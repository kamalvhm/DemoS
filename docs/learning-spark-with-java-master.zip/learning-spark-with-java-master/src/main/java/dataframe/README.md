# DataFrame, or Dataset<Row>

## Getting started

| File                  | What's Illustrated    |
|-----------------------|-----------------------|
| FromRowsAndSchema.java | Create `Dataset<Row>` from `Row`s and an explicit schema. |
| DatasetConversion.java | Convert between `Dataset<Row>` and Dataset of some other type (in both directions.) |
