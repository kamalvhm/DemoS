# _PairRDD_ Examples

| File                  | What's Illustrated    |
|-----------------------|-----------------------|
| Basic.java      | Creation of and basic operations on a JavaPairRDD. **Start here.** |