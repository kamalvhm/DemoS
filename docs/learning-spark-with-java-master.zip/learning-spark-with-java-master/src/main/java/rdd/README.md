# RDD

## Getting started

| File                  | What's Illustrated    |
|-----------------------|-----------------------|
| Basic.java      | How to create a JavaRDD, examine it and perform basic transformations. **Start here.** |
